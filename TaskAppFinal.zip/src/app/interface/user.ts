export interface user  {
    username:string,
    id?:number
    Task?:Array<string>
}