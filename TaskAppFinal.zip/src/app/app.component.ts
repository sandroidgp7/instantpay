import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { user } from "./interface/user";
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';


@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {
  title = "TaskApp";
  public UserForm: FormGroup;
  public UserList: Array<any>=[]
  public currentUser:any=0
  public taskStr:string=''
  constructor(private fb: FormBuilder) {
    this.UserForm = this.fb.group({
      username: ["", [Validators.required,Validators.minLength(1)]],
      Task:[[]]
    });
  }

  ngOnInit(): void {}

  get UserFormVal() {
    return this.UserForm.controls;
  }
  addTaskArray(){

  }

  addNewUser(data:user){
    if(this.UserForm.invalid)
      return 
    let User:user=data;
        User.id = Math.random()*100000
    this.UserList.push(Object.assign({},data))
    this.UserForm.reset()
    this.UserForm.patchValue({Task:[]})
    console.log(this.UserList)

  }
  drop(event: CdkDragDrop<string[] | any>) {
    if (event.previousContainer !== event.container) {
      this.transferArrayItem(event.previousContainer.id, event.container.id,
        event.previousIndex, event.currentIndex)
    } 
    // else {
    //   moveItemInArray(this.UserList, event.previousIndex, event.currentIndex);
    // }
    console.log(event)
    }
    transferArrayItem(previousContainer:any,container:any,previousIndex:any,currentIndex:any){
      console.log(previousContainer,container,previousIndex,currentIndex)
        let item:any = this.UserList[previousContainer].Task?.slice()
        let itemMove=item.splice(previousIndex,1)
        this.UserList[previousContainer].Task = item 
        console.log(item,itemMove)
        let newlist = this.UserList[container].Task?.slice() || []
        console.log({newlist})
        newlist?.splice(currentIndex,0,itemMove[0])
        this.UserList[container].Task = newlist || []
    }
    deleteUser(index:number){
      this.UserList.splice(index,1)
    }
    addUserTask(){
      if(this.taskStr==''){
        alert('task is empty')
        return
      }
      this.UserList[this.currentUser].Task?.push(this.taskStr) 
      this.taskStr=''
    }
    deleteTask(indexi:any,indexj:any){
      let item:any = this.UserList[indexi].Task?.slice()
        let itemMove=item.splice(indexj,1)
        this.UserList[indexi].Task = item 
    }
    changeheader(event:any,index:any){
      console.log(event.target.value)
      this.UserList[index].username = event.target.value
      console.log(this.UserList)


    }
    changetask(event:any,indexi:any,indexj:any){
      this.UserList[indexi].Task[indexj] = event.target.value      
      console.log(this.UserList)
    }

}
